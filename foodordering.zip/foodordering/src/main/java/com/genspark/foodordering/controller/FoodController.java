package com.genspark.foodordering.controller;

import com.genspark.foodordering.entity.MenuItems;
import com.genspark.foodordering.entity.Restaurant;
import com.genspark.foodordering.exception.ResourceNotFoundException;
import com.genspark.foodordering.serrepository.MenuRepo;
import com.genspark.foodordering.serrepository.RestaurantRepo;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
//@RequestMapping
@Slf4j
public class FoodController {
    @Autowired
    private RestaurantRepo restaurantRepository;
    @Autowired
    private MenuRepo menuRepo;

    @PostMapping("/addRestaurant")
    public Restaurant saveRestaurant(@RequestBody Restaurant restaurant){
        log.info("INSIDE saveRestaurant METHOD ****************************************************");

        return restaurantRepository.save(restaurant);

    }
    @PostMapping("/addMenuItems")
    public MenuItems saveMenuItems(@RequestBody MenuItems menuItems){
        log.info("INSIDE inside menuitem METHOD ****************************************************");

        return menuRepo.save(menuItems);
    }


    //@PostMapping("/addMenuItem")
    //public MenuItems addItem(@RequestBody MenuItems menuItem)
    //{
       // return  this.orderService.addItem(menuItem);
      //  return this.restaurantRepository.(menuItem);
    //}


    // get all restaurant
   // @GetMapping("/restaurant")
    //public ResponseEntity<List<Restaurant>> getAllRetaurant(@RequestParam(required = false) String name) {
      //  List<Restaurant> restaurants = new ArrayList<Restaurant>();

        //if (name == null)
          //  restaurantRepository.findAll().forEach(restaurants::add);
        //else
          //  restaurantRepository.findByName(name).forEach(restaurants::add);
        //if (restaurants.isEmpty()) {
          //  return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        //}
        //return new ResponseEntity<>(restaurants, HttpStatus.OK);
    //}

   // @GetMapping("/restaurants/{id}/")
    //public List<MenuItems> getRestaurantsMenuItems(@PathVariable("id") Long id){
      //  return restaurantRepository.findByMenuItems(id);

    //}
    //@PostMapping("/menuItem")
    //public List<MenuItems> getRestaurantsMenuItems(@PathVariable("id") Long id){
      //  return restaurantRepository.findByMenuItems(id);

    //}


   //   @GetMapping("/restaurants/{id}/menuitems")
 //   public ResponseEntity<MenuItems> getAllMenuItemsByRestaurantId(@PathVariable(value ="regId") long RegId){
     //   Restaurant restaurant = restaurantRepository.findById(id)
       //         .orElseThrow(()->new ResourceNotFoundException("Not found Restaurant with Id = + id"));
      //  List<MenuItems>menuItems = menuRepo.findByRestaurantId(regId);
        //  return new ResponseEntity<>(menuItems, HttpStatus.OK);

            //}

            //public ResponseEntity<Restaurant>  createRestaurant(@RequestBody Restaurant restaurant){
               // Restaurant _restaurant = restaurantRepository.save(new Restaurant(restaurant.getName(), restaurant.getAddress(), restaurant.getEmails(), restaurant.getRegdoc(),true))


            }


