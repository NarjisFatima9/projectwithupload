package com.genspark.foodordering.entity;

import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tb_restaurant")
public class Restaurant {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long regId;
    @NonNull
    private String name;
    @NonNull
    private String address;
    //@NonNull
    private String emails;
  //  @Lob
    //@Column(name = "name", columnDefinition = "BLOB")
   // private byte[] regdoc;

  // @OneToMany
    //   @OneToMany(cascade =CascadeType.ALL)
    //@JoinColumn(name = "rc_fid", referencedColumnName = "regId")
    //List<MenuItems> menuItems = new ArrayList<>();
}
