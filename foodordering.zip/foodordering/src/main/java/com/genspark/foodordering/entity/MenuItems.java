package com.genspark.foodordering.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tb_menuItems")
public class MenuItems {
    @Id
    @GeneratedValue(strategy =  GenerationType.AUTO)
    private long itemId;
    private String itemName;
    private double itemPrice;

    private Long refKey;

   //@ManyToOne(fetch = FetchType.LAZY, optional = false)
    //@ManyToOne
   //@JoinColumn(name = "FregId", referencedColumnName = "regId")
    //   @JoinColumn(name = "FregId",nullable = false, referencedColumnName = "regId")
   // @OnDelete(action = OnDeleteAction.CASCADE)
   // @JsonIgnore
    //private Restaurant restaurant;

}
