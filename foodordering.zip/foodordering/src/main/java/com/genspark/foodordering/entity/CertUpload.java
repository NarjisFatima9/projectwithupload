package com.genspark.foodordering.entity;

public class CertUpload {
}
