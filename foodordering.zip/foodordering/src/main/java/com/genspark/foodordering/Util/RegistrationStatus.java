package com.genspark.foodordering.Util;

public class RegistrationStatus {
    public static final int NEW = 0;
    public static final int COMPLETE = 1;
}
