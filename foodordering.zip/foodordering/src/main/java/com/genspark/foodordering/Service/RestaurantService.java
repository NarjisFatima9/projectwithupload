package com.genspark.foodordering.Service;

import com.genspark.foodordering.entity.MenuItems;
import com.genspark.foodordering.entity.Restaurant;
import com.genspark.foodordering.serrepository.MenuRepo;
import com.genspark.foodordering.serrepository.RestaurantRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RestaurantService{

    @Autowired
    private RestaurantRepo restaurantRepo;
    @Autowired
    private MenuRepo menuRepo;

    public RestaurantService(){

    }
  //  Order addOrder(Order order);

    //@Override
    //public Order addOrder(Order order) {
      //  return this.orderDao.save(order);

    public Restaurant saveRestaurant(Restaurant restaurant){
         return this.restaurantRepo.save(restaurant);
    }
   public MenuItems saveMenuItems(MenuItems menuItems){
        return this.menuRepo.save(menuItems);
    }




    //public MenuItems addItems(MenuItems menuItems) {
      //  return this.menuRepo.save(menuItems);
    //}



}
