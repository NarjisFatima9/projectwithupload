package com.genspark.foodordering.Service;

import com.genspark.foodordering.entity.MenuItems;
import com.genspark.foodordering.entity.Restaurant;

import java.util.List;

public interface RestaurantServiceInt {
    Restaurant saveRestaurant(Restaurant restaurant);
    MenuItems saveMenuItems(MenuItems restaurant);


    //String deleteItemById(long itemId);
    //List<Restaurant> findByRegId(Long restId);
    //List<Restaurant> findByName(String name);
    //Restaurant regRestaurant(Restaurant restaurant);

  //  List<MenuItems> findByMenuItems(Long id);
   // void deleteOrder(long parseLong);


}
