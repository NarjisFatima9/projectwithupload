package com.genspark.foodordering;

//import com.genspark.foodordering.entity.MenuItems;
//import com.genspark.foodordering.entity.Restaurant;
//import com.genspark.foodordering.serrepository.RestaurantRepo;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import static jdk.internal.org.jline.reader.impl.LineReaderImpl.CompletionType.List;

@SpringBootApplication
public class FoodorderingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodorderingApplication.class, args);
	}


}
